SHARED_TENANT = {
    "id": "00000000-0000-0000-0000-000000000000",
    "name": "Shared",
    "description": "",
    "main": False,
    "disabled": False,
    "eps": 0,
    "epsLimit": 0,
    "createdAt": 0000000000000,
    "updatedAt": 0000000000000,
}
